package com.example.pdf.controller;

import android.content.Context;

import com.example.pdf.dao.ClienteDao;
import com.example.pdf.modelo.Cliente;

import java.util.ArrayList;
public class ClienteController {

    private Context context;

    public ClienteController(Context context){
        this.context = context;
    }


    public String salvarAluno(String nome, String cpf){
        try{
            //validar se os campos estão vazios

            if(nome.equals(" ") || nome.isEmpty()){
                return "Informe o NOME do Cliente";
            }
            if(cpf.equals(" ")||cpf.isEmpty()){
                return "Informe o CPF do Cliente";
            }
            //validar se já existe o aluno cadastrado

            Cliente cliente = ClienteDao.getInstancia(context).getById(Integer.parseInt(cpf));


            if(cliente != null){
                return "O Ra("+cpf+") já esta cadastrado";
            }else{
                cliente = new Cliente();
                cliente.setNome(nome);
                cliente.setCpf(cpf);

                ClienteDao.getInstancia(context).insert(cliente);
            }


        }catch(Exception ex){
            return "Erro ao gravar Cliente";
        }

        return null;
    }

    public ArrayList<Cliente> retornaClientes(){
        return ClienteDao.getInstancia(context).getAll();
    }
}

