package com.example.pdf.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pdf.R;
import com.example.pdf.modelo.Cliente;


import java.util.ArrayList;

public class ClienteListAdapter extends RecyclerView.Adapter<ClienteListAdapter.ViewHolder> {

    private ArrayList<Cliente> listaClientes;

    private Context context;

    public ClienteListAdapter(ArrayList<Cliente> listaClientes, Context context) {
        this.listaClientes = listaClientes;
        this.context = context;
    }

    @NonNull
    @Override
    public ClienteListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View listView = inflater.inflate(R.layout.item_list_cliente, parent, false);



        return new ViewHolder(listView);
    }

    @Override
    public void onBindViewHolder(@NonNull ClienteListAdapter.ViewHolder holder, int position) {

        Cliente clienteSelecionado = listaClientes.get(position);
        holder.tvNome.setText(String.valueOf(clienteSelecionado.getNome()));
        holder.tvCpf.setText(String.valueOf(clienteSelecionado.getCpf()));



    }

    @Override
    public int getItemCount() {
        return listaClientes.size();
    }
    public class ViewHolder extends RecyclerView.ViewHolder{

        public TextView tvCpf;
        public TextView tvNome;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);


            this.tvCpf = itemView.findViewById(R.id.tvCpf);
            this.tvNome = itemView.findViewById(R.id.tvNome);
        }
    }
}
