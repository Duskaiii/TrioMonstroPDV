package com.example.pdf.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


import com.example.pdf.helper.SQLiteDataHelper;


import com.example.pdf.modelo.Produto;

import java.util.ArrayList;
public class ProdutoDao implements IGenericDao<Produto>{

    //Variavel responsavel por abrir o conexão com a Base de Dados
    private SQLiteOpenHelper openHelper;

    //Base de dados (física)
    private SQLiteDatabase baseDados;

    //Nome das colunas da tabela (Não é necessário, é apenas para facilitar)
    private String[]colunas = {"CODIGO", "NOME", "VALOR"};

    //nome da tabela
    private String tabela = "PRODUTO";

    //Contexto (View)
    private Context context;

    //Metodo para garantir uma unica instancia no DAO
    private static ProdutoDao instancia;

    public static ProdutoDao getInstancia(Context context){
        if (instancia == null){
            return instancia = new ProdutoDao(context);
        }else{
            return instancia;
        }
    }

    private ProdutoDao(Context context){
        this.context = context;

        ///Abrir a conexão com a base de dados

        openHelper = new SQLiteDataHelper(this.context, "Unipar_Toledo", null, 1);


        //instancia a base de dados
        baseDados = openHelper.getWritableDatabase();

    }

    @Override
    public long insert(Produto obj) {

        //long retorna a linha na qual foi feita o insert (se retornar 0 ou -1, é pq falhou)

        try{
            ContentValues valores = new ContentValues();

            valores.put(colunas[0], obj.getCodigo());
            //valores.put("RA", obj.getRa());
            valores.put(colunas[1], obj.getNome());
            //valores.put("NOME", obj.getNome());
            valores.put(colunas[2], obj.getValor());

            return baseDados.insert(tabela, null, valores);

        }catch(SQLException ex){
            Log.e("UNIPAR", "Erro ProdutoDao.insert() :"+ex.getMessage());
        }


        return 0;
    }

    @Override
    public long update(Produto obj) {

        try{

            ContentValues valores = new ContentValues();

            valores.put(colunas[1], obj.getNome());

            //Identificador para a clausula WHERE
            String[]identificador = {String.valueOf(obj.getCodigo())};

            //return baseDados.update(tabela, valores, "RA = ?")
            return baseDados.update(tabela, valores, colunas[0]+ " = ?", identificador);



        }catch(SQLException ex){
            Log.e("UNIPAR", "Erro ProdutoDao.update()"+ex.getMessage());
        }

        return 0;
    }

    @Override
    public long delete(Produto obj) {

        try{

            //Clausula WHERE
            String[]identificador =  {String.valueOf(obj.getCodigo())};

            return baseDados.delete(tabela, colunas[0]+ " = ?",identificador);

        }catch(SQLException ex){
            Log.e("UNIPAR", "Erro ClienteDao.delete()"+ex.getMessage());
        }

        return 0;
    }

    @Override
    public ArrayList<Produto> getAll() {

        ArrayList<Produto> lista = new ArrayList<>();

        try{

            Cursor cursor = baseDados.query(tabela, colunas, null, null, null, null, colunas[0]);

            //Move o CURSOR para a primeira posição ( Se retornar FALSE, é pq não tem nenhuma dado na tabela)
            if(cursor.moveToFirst()){
                do{
                    Produto produto = new Produto();
                    produto.setCodigo(cursor.getString(0));
                    produto.setNome(cursor.getString(1));
                    produto.setValor(cursor.getString(2));

                    lista.add(produto);

                }while(cursor.moveToNext());

            }

        }catch(SQLException ex){
            Log.e("UNIPAR", "Erro ClienteDao.getAll()"+ex.getMessage());
        }

        return lista;
    }

    @Override
    public Produto getById(int id) {

        try{

            String[]indentificador = {String.valueOf(id)};

            Cursor cursor = baseDados.query(tabela, colunas, colunas[0]+"= ?", indentificador, null, null, null);

            if(cursor.moveToFirst()){
                Produto produto = new Produto();
                produto.setCodigo(cursor.getString(0));
                produto.setNome(cursor.getString(1));
                produto.setValor(cursor.getString(1));
                return produto;
            }

        }catch(SQLException ex){
            Log.e("UNIPAR", "Erro ProdutoDao.getById()"+ex.getMessage());
        }

        return null;
    }

}
