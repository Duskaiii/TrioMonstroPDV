package com.example.pdf;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.example.pdf.R;
import com.example.pdf.adapter.ClienteListAdapter;
import com.example.pdf.controller.ClienteController;
import com.example.pdf.modelo.Cliente;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class ClienteActivity extends AppCompatActivity {

    private EditText edCpf;
    private EditText edNome;



    private FloatingActionButton btCadastroCliente;
    private AlertDialog cadastroDialog;

    private ClienteController controller;
    private RecyclerView rvAlunos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cliente);

        setTitle("CADASTRO CLIENTE");

        btCadastroCliente = findViewById(R.id.btCadastroAluno);
        rvAlunos = findViewById(R.id.rvCliente);
        controller = new ClienteController(this);



        btCadastroCliente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirCadastroCliente();
            }
        });

        carregarListaClientes();


    }

     private void carregarListaClientes() {

        ArrayList<Cliente> listaClientes = controller.retornaClientes();
        ClienteListAdapter adapter = new ClienteListAdapter(listaClientes, this);

        rvAlunos.setLayoutManager(new LinearLayoutManager(this));
        rvAlunos.setAdapter(adapter);

    }

    private void abrirCadastroCliente() {
        //carregar arquivo xml do leyout
        View viewAlert = getLayoutInflater().inflate(R.layout.dialog_cadastro_cliente,null);

        edNome = viewAlert.findViewById(R.id.edNome);
        edCpf = viewAlert.findViewById(R.id.edCpf);


        ///carregar os componentes do AlertDialog

        final AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("CADASTRO DE CLIENTE"); // setando o titulo

        builder.setView(viewAlert); //setando o layout

        builder.setCancelable(false); //impedir que feche o popup ao clicar fora da tela


        //Carregando os botões na tela
        builder.setNegativeButton("CANCELAR", null);
        builder.setPositiveButton("SALVAR", null);

        //Construindo o layout
        cadastroDialog = builder.create();


        //Setando ação no botão salvar
        cadastroDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialogInterface) {
                Button btSalvar = cadastroDialog.getButton(AlertDialog.BUTTON_POSITIVE);

                btSalvar.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        salvarCliente();
                    }
                });
            }
        });

        cadastroDialog.show();
    }

    private void salvarCliente() {
        String retorno = controller.salvarAluno(edNome.getText().toString(), edCpf.getText().toString());

        if(retorno != null){
            //setar os erros
            if(retorno.contains("Nome")){
                edNome.setError((retorno));
                edNome.requestFocus();
            }
            else if(retorno.contains("CPF")){
                edCpf.setError((retorno));
                edCpf.requestFocus();
            }else{
                Toast.makeText(this, retorno,  Toast.LENGTH_SHORT).show();
            }

        }else{
            Toast.makeText(this, "Cliente cadastrado com sucesso", Toast.LENGTH_LONG).show();
            cadastroDialog.dismiss();

            carregarListaClientes();
        }
    }


}