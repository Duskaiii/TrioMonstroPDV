package com.example.pdf;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;


public class ClienteActivity extends AppCompatActivity {

    private ImageButton btRetornaC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cliente);

        btRetornaC = findViewById(R.id.btRetornaC);


        btRetornaC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirActivity(VendaActivity.class);
            }
        });




    }



    private void abrirActivity(Class<?> activity){
        Intent intent = new Intent(ClienteActivity.this, activity);
        startActivity(intent);
    }
}