package com.example.pdf.controller;

import android.content.Context;

import com.example.pdf.dao.ClienteDao;
import com.example.pdf.dao.ProdutoDao;
import com.example.pdf.modelo.Cliente;
import com.example.pdf.modelo.Produto;

import java.util.ArrayList;
public class ProdutoController {

    private Context context;

    public ProdutoController(Context context){
        this.context = context;
    }

    public String salvarProduto(String codigo, String nome, String valor){
        try{
            //validar se os campos estão vazios

            if(codigo.equals(" ") || codigo.isEmpty()){
                return "Informe o codigo do Produto";
            }
            if(nome.equals(" ") || nome.isEmpty()){
                return "Informe o NOME do Produto";
            }
            if(valor.equals(" ")||valor.isEmpty()){
                return "Informe o valor do Produto";
            }
            //validar se já existe o aluno cadastrado

            Produto produto = ProdutoDao.getInstancia(context).getById(Integer.parseInt(codigo));


            if(produto != null){
                return "O Ra("+valor+") já esta cadastrado";
            }else{
                produto = new Produto();
                produto.setCodigo(codigo);
                produto.setNome(nome);
                produto.setValor(valor);

                ProdutoDao.getInstancia(context).insert(produto);
            }


        }catch(Exception ex){
            return "Erro ao gravar Cliente";
        }

        return null;
    }

    public ArrayList<Produto> retornaProduto(){
        return ProdutoDao.getInstancia(context).getAll();
    }
}
