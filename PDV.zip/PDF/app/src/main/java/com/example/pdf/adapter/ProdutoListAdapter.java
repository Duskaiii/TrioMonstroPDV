package com.example.pdf.adapter;

public class ProdutoListAdapter {
}
