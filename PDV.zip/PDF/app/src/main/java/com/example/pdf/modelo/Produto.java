package com.example.pdf.modelo;

public class Produto {

    private String codigo;
    private String nome;
    private double valorUn;

    public Produto() {
    }

    public Produto(String codigo, String descricao, double valorUn) {
        this.codigo = codigo;
        this.nome = nome;
        this.valorUn = valorUn;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getDescricao() {
        return nome;
    }

    public void setNome(String descricao) {
        this.nome = nome;
    }

    public double getValorUn() {
        return valorUn;
    }

    public void setValorUn(double valorUn) {
        this.valorUn = valorUn;
    }
}
