package com.example.pdf;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.pdf.modelo.Cliente;
import com.example.pdf.modelo.ItemPedido;
import com.example.pdf.modelo.Produto;

import java.util.ArrayList;
import java.util.Random;

public class VendaActivity extends AppCompatActivity {

    private ImageButton btRetorna;
    private TextView tvCaixa;
    private ImageButton btCliente;
    private Spinner spCliente;
    private TextView tvRetornaCpf;
    private Spinner spProduto;
    private EditText edQuantProd;
    private TextView edValorProd;
    private ImageButton btRemove;
    private ImageButton btAdd;
    private TextView tvRetornaItens;
    private ImageButton btCancela;
    private ImageButton btConfirma;
    private TextView tvRetornaCaixa;


    private int posicaoSelecionada = 0;

    private ArrayList<Cliente> listaCliente;
    private ArrayList<Produto> listaProduto;
    private ArrayList<ItemPedido> itemPedido;

    private TextView tvRetornaTotalFinal;
    private TextView tvErroProduto;
    private TextView tvErroCliente;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_venda);


        tvRetornaCaixa = findViewById(R.id.tvRetornaCaixa);
        btRetorna = findViewById(R.id.btRetorna);
        btCliente = findViewById(R.id.btCliente);
        tvCaixa = findViewById(R.id.tvCaixa);
        spCliente = findViewById(R.id.spCliente);
        tvRetornaCpf = findViewById(R.id.tvRetornaCpf);
        spProduto = findViewById(R.id.spProduto);
        edQuantProd = findViewById(R.id.edQuantProd);
        edValorProd = findViewById(R.id.edValorProd);
        btRemove = findViewById(R.id.btRemove);
        btAdd = findViewById(R.id.btAdd);
        tvRetornaItens = findViewById(R.id.tvRetornaItens);
        btCancela = findViewById(R.id.btCancela);
        btConfirma = findViewById(R.id.btConfirma);
        tvRetornaTotalFinal = findViewById(R.id.tvRetornaTotalFinal);




        geraCodigo();

        btRetorna.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirActivity(MainActivity.class);
            }
        });

        btCliente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirActivity(com.example.pdf.ClienteActivity.class);
            }
        });


        btAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                adicionarItemVenda();

            }


        });

        spProduto.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView,
                                       View view, int posicao, long l) {
                if(posicao > 0){
                    posicaoSelecionada = posicao;
                    tvErroProduto.setVisibility(View.GONE);
                    exibeValorUnitario();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }

        });

        spCliente.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView,
                                       View view, int posicao, long l) {
                if(posicao > 0){
                    posicaoSelecionada = posicao;
                    tvErroCliente.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        btAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                adicionarItemVenda();

            }
        });

    }

    private void geraCodigo(){

        int cod = new Random().nextInt(1000);
        tvRetornaCaixa.setText(""+cod);
    }

    private void abrirActivity(Class<?> activity){
        Intent intent = new Intent(VendaActivity.this, activity);
        startActivity(intent);
    }


    private void atualizaListaProduto(){
        ArrayList<ItemPedido> lista = Controller.getInstancia().retornaItemPedido();
        String texto = "";

        /* Valor total Prod */
        double vl =0;




        for (ItemPedido item : lista) {

            Produto prod = item.getProduto();

            texto += prod.getCodigo()+" - "+prod.getDescricao()+"\nQtd: "+item.getQuantidade()+ " " +
                    "- VL Un.: "+item.getVlrVenda() + "\nVL Total: "+item.getVlrVenda()*item.getQuantidade()+"\n" +
                    "----------------------------\n";


            vl += item.getQuantidade() * item.getVlrVenda();



        }

        tvRetornaTotalFinal.setText(Double.toString(vl));



        tvRetornaItens.setText(texto);
    }

    private void adicionarItemVenda(){

        ItemPedido itemPedido = new ItemPedido();
        Produto prod = listaProduto.get(posicaoSelecionada -1);


        //Validação Quantidade
        if(edQuantProd.getText().toString().isEmpty()){
            edQuantProd.setError("Informe uma quantidade!");
            return;
        }
        if(edQuantProd.getText().toString().equals("0")){
            edQuantProd.setError("Quantidade inforamada invalida!");
            return;
        }
        if(edQuantProd.getText().toString().contains("-")){
            edQuantProd.setError("Não e possivel adicionar com quantidade negativa!");
            return;
        }


        //Validação Valor unt
        if(edValorProd.getText().toString().isEmpty()){
            edValorProd.setError("Valor do produto em Branco!");
            return;
        }
        if(edValorProd.getText().toString().equals("0")){
            edValorProd.setError("Valor unitario zerado!");
            return;
        }
        if(edValorProd.getText().toString().contains("-")){
            edValorProd.setError("Valor unitario Negativo!");
            return;
        }

        itemPedido.setProduto(prod);
        itemPedido.setQuantidade(Integer.parseInt(edQuantProd.getText().toString()));
        itemPedido.setVlrVenda(Double.parseDouble(edValorProd.getText().toString()));

        Controller.getInstancia().salvarItemPedido(itemPedido);

        Toast.makeText(VendaActivity.this, "Produto adicionado com sucesso", Toast.LENGTH_SHORT);

        atualizaListaProduto();

        edQuantProd.setText("");
        edValorProd.setText("");

        //Retorna o radioButtom para a posição 0
        spProduto.setSelection(0);

    }

    private void carregaCliente() {
        listaCliente = Controller.getInstancia().retornarCliente();
        String[]vetCli = new String[listaCliente.size() + 1];
        vetCli[0] = "Selecione o Cliente";
        for (int i = 0; i < listaCliente.size(); i++) {
            Cliente cliente1 = listaCliente.get(i);
            vetCli[i+1] = cliente1.getNome();
        }
        ArrayAdapter adapter = new ArrayAdapter(
                VendaActivity.this,
                android.R.layout.simple_dropdown_item_1line,
                vetCli);

        spCliente.setAdapter(adapter);

    }

    private void carregaProduto() {
        listaProduto = Controller.getInstancia().retornarProduto();
        String[]vetProd = new String[listaProduto.size() + 1];
        vetProd[0] = "Selecione o produto";
        for (int i = 0; i < listaProduto.size(); i++) {
            Produto produto1 = listaProduto.get(i);
            vetProd[i+1] = produto1.getCodigo()+" - "+produto1.getDescricao();
        }
        ArrayAdapter adapter = new ArrayAdapter(
                VendaActivity.this,
                android.R.layout.simple_dropdown_item_1line,
                vetProd);

        spProduto.setAdapter(adapter);

    }

    private void exibeValorUnitario() {
        ArrayList<Produto> lista = Controller.getInstancia().retornarProduto();
        String exibeValorUni = "";
        exibeValorUni += lista.get(posicaoSelecionada -1).getValorUn();

        edValorProd.setText(exibeValorUni);
    }

    public void abrirCadastroCliente(View view) {

        Intent intent = new Intent(VendaActivity.this, ClienteActivity.class);

        startActivity(intent);

    }

}