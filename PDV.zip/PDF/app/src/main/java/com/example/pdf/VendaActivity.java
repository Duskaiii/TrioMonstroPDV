package com.example.pdf;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextClock;
import android.widget.TextView;

public class VendaActivity extends AppCompatActivity {

    private ImageButton btRetorna;

    private TextView tvCaixa;
    private Button btCliente;
    private Spinner spCliente;
    private TextView tvRetornaCpf;
    private Spinner spProduto;
    private EditText edQuantProd;
    private EditText edValorProd;
    private ImageButton btRemove;
    private ImageButton btAdd;
    private TextView tvRetornaItens;
    private ImageButton btCancela;
    private ImageButton brConfirma;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_venda);
    }
}