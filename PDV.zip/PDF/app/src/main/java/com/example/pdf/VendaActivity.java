package com.example.pdf;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.pdf.controller.ClienteController;
import com.example.pdf.controller.ProdutoController;
import com.example.pdf.modelo.Cliente;
import com.example.pdf.modelo.ItemPedido;
import com.example.pdf.modelo.Produto;

import java.util.ArrayList;
import java.util.Random;

public class VendaActivity extends AppCompatActivity {

    private Button btRetorna;
    private TextView tvCaixa;
    private ImageButton btCliente;
    private AutoCompleteTextView AcCliente;
    private TextView tvRetornaCpf;
    private AutoCompleteTextView AcProduto;
    private EditText edQuantProd;
    private TextView edValorProd;
    private Button btRemove;
    private Button btAdd;
    private TextView tvRetornaItens;
    private Button btCancela;
    private Button btConfirma;
    private TextView tvRetornaCaixa;


    private ClienteController clienteController;

    private ProdutoController produtoController;
    private int posicaoSelecionada = 0;

    private ArrayList<Cliente> listaCliente;
    private ArrayList<Produto> listaProduto;
    private ArrayList<ItemPedido> itemPedido;

    private TextView tvRetornaTotalFinal;
    private TextView tvErroProduto;
    private TextView tvErroCliente;


    private ArrayList<Cliente>retorna;
    private ArrayList<Produto>retornaP;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_venda);


        tvRetornaCaixa = findViewById(R.id.tvRetornaCaixa);
        //btRetorna = findViewById(R.id.btRetorna);
        btCliente = findViewById(R.id.btCliente);
        tvCaixa = findViewById(R.id.tvCaixa);
        AcCliente = findViewById(R.id.AcCliente);
        //tvRetornaCpf = findViewById(R.id.tvRetornaCpf);
        AcProduto = findViewById(R.id.AcProduto);
        edQuantProd = findViewById(R.id.edQuantProd);
        edValorProd = findViewById(R.id.edValorProd);
        btRemove = findViewById(R.id.btRemove);
        btAdd = findViewById(R.id.btAdd);
        tvRetornaItens = findViewById(R.id.tvRetornaItens);
        btCancela = findViewById(R.id.btCancela);
        btConfirma = findViewById(R.id.btConfirma);
        tvRetornaTotalFinal = findViewById(R.id.tvRetornaTotalFinal);



        clienteController = new ClienteController(this);

        retornarClientes();


        geraCodigo();

//        btRetorna.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                abrirActivity(MainActivity.class);
//            }
//        });

        btCliente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirActivity(com.example.pdf.ClienteActivity.class);
            }
        });


        btAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // adicionarItemVenda();

            }


        });

//        spProduto.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> adapterView,
//                                       View view, int posicao, long l) {
//                if(posicao > 0){
//                    posicaoSelecionada = posicao;
//                    tvErroProduto.setVisibility(View.GONE);
//                   // exibeValorUnitario();
//                }
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> adapterView) {
//
//            }
//
//        });

//        AcCliente.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> adapterView,
//                                       View view, int posicao, long l) {
//                if(posicao > 0){
//                    posicaoSelecionada = posicao;
//                    tvErroCliente.setVisibility(View.GONE);
//                }
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> adapterView) {
//
//            }
//        });

        btAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


            }
        });

    }


    private void retornarClientes(){

        retorna = new ArrayList<>();

        retorna = clienteController.retornaClientes();

        String vetor[] = new String[retorna.size()];

        for (int i = 0; i < retorna.size(); i++) {

            vetor[i] = retorna.get(i).getNome();

        }

        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line,vetor);

        AcCliente.setAdapter(adapter);
    }

    private void retornarProduto(){

        retornaP = new ArrayList<>();

        retornaP = produtoController.retornaProduto();

        String vetor[] = new String[retornaP.size()];

        for (int i = 0; i < retornaP.size(); i++) {

            vetor[i] = retornaP.get(i).getNome();

        }

        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line,vetor);

        AcProduto.setAdapter(adapter);
    }

    private void geraCodigo(){

        int cod = new Random().nextInt(1000);
        tvRetornaCaixa.setText(""+cod);
    }

    private void abrirActivity(Class<?> activity){
        Intent intent = new Intent(VendaActivity.this, activity);
        startActivity(intent);
    }


//    private void atualizaListaProduto(){
//        ArrayList<ItemPedido> lista = clienteController.retornaClientes();
//        String texto = "";
//
//        /* Valor total Prod */
//        double vl =0;
//
//
//
//
//        for (ItemPedido item : lista) {
//
//            Produto prod = item.getProduto();
//
//            texto += prod.getCodigo()+" - "+prod.getDescricao()+"\nQtd: "+item.getQuantidade()+ " " +
//                    "- VL Un.: "+item.getVlrVenda() + "\nVL Total: "+item.getVlrVenda()*item.getQuantidade()+"\n" +
//                    "----------------------------\n";
//
//
//            vl += item.getQuantidade() * item.getVlrVenda();
//
//
//
//        }
//
//        tvRetornaTotalFinal.setText(Double.toString(vl));
//
//
//
//        tvRetornaItens.setText(texto);
//    }






    public void abrirCadastroCliente(View view) {

        Intent intent = new Intent(VendaActivity.this, ClienteActivity.class);

        startActivity(intent);

    }

}